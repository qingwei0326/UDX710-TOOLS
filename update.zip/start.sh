#!/bin/sh
cd /home/root/6677
chmod 755 *
./server &
